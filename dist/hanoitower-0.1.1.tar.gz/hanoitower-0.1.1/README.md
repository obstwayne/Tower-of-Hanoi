﻿# Tower-of-Hanoi
There is bugs: when you click on the area between the towers, an error will occur and you will have to start again; Sometimes the disk can return to the first tower, even if there is already a smaller disk there.
